import { Component } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { CurrencyPipe } from '@angular/common';
import { CartService } from '../../services/cart.service';
import { RouterLink } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-listing',
  standalone: true,
  imports: [CurrencyPipe,RouterLink],
  templateUrl: './product-listing.component.html',
  styleUrl: './product-listing.component.css'
})
export class ProductListingComponent {

  userId = sessionStorage.getItem("id");
  products:any;


  constructor(private productService:ProductService,private cartService:CartService,private toastr: ToastrService){}

  getProducts(){
    this.productService.getProducts().subscribe((data:any)=>{
      this.products = data;
    }) 
  }
  
  ngOnInit(): void {
  this.getProducts()

  }

  addToCart(itemProductId:any){
    const data = {
      productId : itemProductId,
      quantity : 1
    }
    this.cartService.addToCart(this.userId,data).subscribe({
      next: (response: any) => {
        this.toastr.success('product added to cart');
      },
      error: (error) => {
        if (error.status === 400) {
          this.toastr.warning('Product out of stock');
        } else {
          alert('An unexpected error occurred. Please try again later.')
        }
      },
    })
  }


}
