import { Component, DoCheck, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { CartService } from '../../services/cart.service';
import { CurrencyPipe, formatDate } from '@angular/common';
import { UserService } from '../../services/user.service';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import * as bootstrap from 'bootstrap';
import { PaymentService } from '../../services/payment.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CurrencyPipe,ReactiveFormsModule],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent implements OnInit{

constructor(private cartService:CartService,private userSerice:UserService,private paymentService:PaymentService,private route:Router){}

userinfo:any;
username = sessionStorage.getItem('username');
userId = sessionStorage.getItem("id");
myCart:any[] = []
cartTotal:number = 0;
cardData:any;

getCartDetails(){
  this.cartService.getCartData(this.userId).subscribe((res:any)=>{
    this.myCart = res;
    this.total();
  })
}

total() {
  this.cartTotal = 0
  for(let i = 0 ;i<this.myCart.length;i++){
    this.cartTotal+=(this.myCart[i].price * this.myCart[i].quantity);
  }
}


ngOnInit(): void {
  this.getCartDetails();
  this.userSerice.getUser(this.username).subscribe((data:any)=>{
  this.userinfo = data;
  })

}


increment(itemProductId:any){
  const data = {
    productId : itemProductId,
    quantity : 1
  }
  this.cartService.addToCart(this.userId,data).subscribe({
    next: (response: any) => {
      this.getCartDetails();
    },
    error: (error) => {
      if (error.status === 400) {
        alert('out of stock')
      } else {
        alert('An unexpected error occurred. Please try again later.')
      }
    },
  })
}

decrement(item:any){
  const data = {
   
    cartId:item.cartId,
    productId : item.productId,
    quantity : 1
  }
  this.cartService.decrementQuantity(data).subscribe((res)=>{
    if(res='success'){
      console.log('decrement works');
      this.getCartDetails();
    }
    else{
      console.log('error');
    }
  })
}

removeProduct(item:any){
 this.cartService.removeProduct(item.productId,item.cartId).subscribe((res)=>{
  if(res='success'){
    console.log('remove works');
    this.getCartDetails();
  }else{
    console.log('error'); 
  }
 })
}

addressForm = new FormGroup({
  addressLine1:new FormControl('', [Validators.required,Validators.minLength(10)]),
  addressLine2:new FormControl('')
})


onCheckout(){
  if(this.userinfo.addressLine1 === null){
    const modal = new bootstrap.Modal(document.getElementById('addressModal')!);
    modal.show(); 
  }else{
    const modal = new bootstrap.Modal(document.getElementById('cardModal')!);
    modal.show(); 
  }
}

saveAddress(){
  const data = {
  userName: this.username,
  addressLine1: this.addressForm.value.addressLine1,
  addressLine2: this.addressForm.value.addressLine2
  }

  this.userSerice.updateUserAddress(data).subscribe((res:any)=>{
    if(res=='success'){
      const modal = new bootstrap.Modal(document.getElementById('cardModal')!);
      modal.show(); 
    }
    else{
      console.log('an error occured');

    }
  })
  
}



cardForm = new FormGroup({
  CardNumber:new FormControl('',[Validators.required,Validators.pattern("^[0-9]{16}$")]),
  ExpiryDate:new FormControl('',[Validators.required]),
  CVV:new FormControl('',[Validators.required,Validators.pattern("^[0-9]{3}$")])
})

validateCard(){
  
  var formData = {
    CardNumber:this.cardForm.value.CardNumber,
    ExpiryDate:this.cardForm.value.ExpiryDate,
    CVV:this.cardForm.value.CVV
  }

  this.paymentService.getCardData().subscribe({
    next: (response: any) => {
     if(
      formData.CardNumber == response[0].CardNumber &&
      formData.ExpiryDate == formatDate(response[0].ExpiryDate,'yyyy-MM','en') &&
      formData.CVV == response[0].CVV
     )
     {
      var data = {
        userId:this.userId,
        cartId:this.myCart[0].cartId,
        subTotal:this.cartTotal
      }
      console.log(data);
      
      this.paymentService.createInvoice(data).subscribe({
        next:(response:any)=>{
          if(response == "success"){
            alert('suceess');
            this.route.navigateByUrl('home/receipt');
          }
          
        },
        error : (error:any)=>{
          alert('an error occured');
        }
      })
      
     }
     else{
      alert ('failure');
     }
      
    }
  })


  
}


get AddressLine1(){
  return this.addressForm.get('addressLine1') as FormControl
}

get CardNumber(){
  return this.cardForm.get('CardNumber') as FormControl
}

get ExpiryDate(){
  return this.cardForm.get('ExpiryDate') as FormControl
}

get CVV(){
  return this.cardForm.get('CVV') as FormControl
}


}
