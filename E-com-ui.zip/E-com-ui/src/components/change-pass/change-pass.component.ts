import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-change-pass',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './change-pass.component.html',
  styleUrl: './change-pass.component.css'
})
export class ChangePassComponent {


  newPasswordDisplay:string = "none";
  confirmPassword:string = "none";  

  ChangePassForm = new FormGroup({
    newPassword:new FormControl('',[Validators.required]),
    cpassword:new FormControl('')
  })

  constructor(private authApi:AuthService,private route:Router){}

  onSubmit(){
    if(this.Npassword.value == this.Cpassword.value)
      {
        this.confirmPassword = 'none';
        var data = {
          userName:sessionStorage.getItem("username"),
          password:this.ChangePassForm.value.newPassword,
        }
  
        this.authApi.changePass(data).subscribe((res:any)=>{
          if(res=="unsuccessful"){
            alert("an error occured")
          }
          else{
            alert("You have successfully changed your password. Please Login")
            sessionStorage.removeItem("token");
            this.route.navigate(['/login'])
          }
        })
      }
      else
      {
        this.confirmPassword = 'inline';
      }
    }
  

  get Npassword() : FormControl{
    return this.ChangePassForm.get('newPassword') as FormControl;
  } 
  get Cpassword():FormControl{
    return this.ChangePassForm.get('cpassword') as FormControl;
  }

}
