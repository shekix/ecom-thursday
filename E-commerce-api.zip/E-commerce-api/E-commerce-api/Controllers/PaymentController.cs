﻿using Core.Models.Sales;
using Infrastructure.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace E_commerce_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly PaymentService _paymentService;
        public PaymentController(PaymentService paymentService)
        {
            _paymentService = paymentService;
        }

        [HttpGet("cardDetail")]
        public async Task<IActionResult> getCardDetail()
        {
            var result = await _paymentService.getCardDetail();
            return Ok(result);
        }

        [HttpPost("createInvoice")]
        public async Task<IActionResult> generateInvoice(SalesMasterDto dto)
        {
            var result = await _paymentService.CreateInvoice(dto);
            if (result == "success")
            {
                return Ok(result);
            } 
            return BadRequest("unsuccessful");
        }

        [HttpGet("receipt")]
        public async Task<IActionResult> getReceipt(int userId)
        {
            var result = await _paymentService.generateReceipt(userId);
            if(result != null)
            {
                return Ok(result);
            }
            return BadRequest(result);
        }
    }
}
