﻿using Core.Models.Cart;
using Infrastructure.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace E_commerce_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly CartService _cartService;

        public CartController(CartService cartService)
        {
            _cartService = cartService;
        }

        [HttpPost("addToCart")]
        public async Task<IActionResult> addToCart(int UserId,CartDetailDto dto)
        {
            var cartId = await _cartService.CreateCart(UserId);
            dto.CartId = cartId;
            var addtoCart = await _cartService.addToCart(dto);
            if(addtoCart != null)
            {
                return Ok("success");
            }
            return BadRequest("outOfStock");
        }

        [HttpGet("cartDetails")]
        public async Task<IActionResult> getCartDetails(int UserId)
        {
            var result = await _cartService.getCartDetails(UserId);
            if(result != null)
            {
                return Ok(result);
            }
            return NotFound();
        }

        [HttpPut("decrementQuantity")]
        public async Task<IActionResult> decrementQuantity(decrementQuantityDto dto)
        {
            var result = await _cartService.decrementQuantity(dto);
            if(result == "success")
            {
                return Ok("successful");
            }
            return BadRequest("unsuccessful");
        }

        [HttpDelete("remove")]
        public async Task<IActionResult> removeProduct(int ProductId,int CartId)
        {
            var result = await _cartService.removeFromCart(ProductId, CartId);
            if(result == "success")
            {
                return Ok("successful");
            }
            return BadRequest("unsuccessful");
        }
    }
}
