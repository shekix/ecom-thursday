﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class CartDetails
    {
        public int Id {  get; set; }
        
        [ForeignKey("CartMaster")]
        public int CartId { get; set; }
        public CartMaster CartMaster { get; set; }

        [ForeignKey("ProductMaster")]
        public int productId { get; set; }
        public ProductMaster ProductMaster { get; set; }

        public int quantity { get; set; }

    }
}
