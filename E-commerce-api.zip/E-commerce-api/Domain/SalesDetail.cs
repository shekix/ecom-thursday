﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class SalesDetail
    {
        public int Id { get; set; }
        public string InvoiceId { get; set; }
        public int ProductID { get; set; }
        public string ProductCode { get; set; }
        public int SaleQunatity { get; set; }
        public float SellingPrice { get; set; }
    }
}
